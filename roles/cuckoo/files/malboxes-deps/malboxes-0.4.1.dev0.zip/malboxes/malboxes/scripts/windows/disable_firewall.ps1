# Disable firewall
netsh advfirewall set allprofiles state off
