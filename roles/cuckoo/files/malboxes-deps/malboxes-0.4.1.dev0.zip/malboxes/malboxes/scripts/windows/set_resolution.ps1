Set-DisplayResolution -Width $env:WIDTH -Height $env:HEIGHT
