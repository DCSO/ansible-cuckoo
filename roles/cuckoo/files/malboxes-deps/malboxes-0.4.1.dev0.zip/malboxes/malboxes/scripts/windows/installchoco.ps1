﻿# ExecutionPolicy is previously set to Unrestricted in Autounattend.xml
iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))


