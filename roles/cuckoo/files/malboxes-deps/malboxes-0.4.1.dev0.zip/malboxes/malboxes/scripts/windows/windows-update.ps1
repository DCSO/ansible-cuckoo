choco install packer-provisioner-windows-update -y
Install-WindowsUpdate -Full
