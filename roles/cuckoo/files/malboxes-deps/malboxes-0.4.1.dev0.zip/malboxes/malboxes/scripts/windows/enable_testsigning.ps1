# Enable testsigning
bcdedit.exe -set TESTSIGNING ON
