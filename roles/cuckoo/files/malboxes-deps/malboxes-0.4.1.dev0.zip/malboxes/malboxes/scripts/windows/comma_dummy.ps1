Write-Host "I am a real Windows!"
