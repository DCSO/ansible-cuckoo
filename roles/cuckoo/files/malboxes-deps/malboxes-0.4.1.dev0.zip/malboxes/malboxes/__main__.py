from malboxes import malboxes

malboxes.main()
